import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const WhatsAppBulkApp());
}

class WhatsAppBulkApp extends StatelessWidget {
  const WhatsAppBulkApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'WhatsApp Broadcaster',
      theme: ThemeData(
        primaryColor: const Color(0xFF075E54),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF075E54),
          foregroundColor: Colors.white,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // சேவ் செய்யப்பட்ட குரூப்கள்
  Map<String, List<Contact>> savedGroups = {};

  final TextEditingController _groupNameController = TextEditingController();
  final TextEditingController _messageController = TextEditingController();

  // போனில் உள்ள காண்டாக்ட்ஸ்களைப் பெறுதல்
  Future<List<Contact>> _getContacts() async {
    if (await FlutterContacts.requestPermission(readonly: true)) {
      return await FlutterContacts.getContacts(withProperties: true);
    }
    return [];
  }

  // புதிய குரூப் உருவாக்குதல்
  void _createNewGroup() async {
    List<Contact> allContacts = await _getContacts();
    List<Contact> selectedContacts = [];

    if (!mounted) return;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          return AlertDialog(
            title: const Text('புதிய குரூப் பெயர்:'),
            content: SizedBox(
              width: double.maxFinite,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: _groupNameController,
                    decoration: const InputDecoration(
                      hintText: 'எ.கா: இன்விடேஷன் லிஸ்ட்',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text('ஆட்களைத் தேர்ந்தெடுக்கவும்:',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  Expanded(
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: allContacts.length,
                      itemBuilder: (context, index) {
                        final contact = allContacts[index];
                        final isSelected = selectedContacts.contains(contact);
                        return CheckboxListTile(
                          title: Text(contact.displayName),
                          subtitle: Text(contact.phones.isNotEmpty
                              ? contact.phones.first.number
                              : 'No number'),
                          value: isSelected,
                          activeColor: const Color(0xFF25D366),
                          onChanged: (val) {
                            setDialogState(() {
                              if (val == true) {
                                selectedContacts.add(contact);
                              } else {
                                selectedContacts.remove(contact);
                              }
                            });
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF075E54)),
                onPressed: () {
                  if (_groupNameController.text.isNotEmpty &&
                      selectedContacts.isNotEmpty) {
                    setState(() {
                      savedGroups[_groupNameController.text] =
                          List.from(selectedContacts);
                    });
                    _groupNameController.clear();
                    Navigator.pop(context);
                  }
                },
                child: const Text('Save Group',
                    style: TextStyle(color: Colors.white)),
              ),
            ],
          );
        },
      ),
    );
  }

  // வாட்ஸ்அப்பிற்கு மெசேஜ் அனுப்புதல்
  void _sendToGroup(String groupName, List<Contact> contacts) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
          top: 20,
          left: 20,
          right: 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Send to: $groupName',
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            TextField(
              controller: _messageController,
              maxLines: 4,
              decoration: const InputDecoration(
                hintText: 'இங்கு மெசேஜ் டைப் செய்யவும்...',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 15),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF25D366),
                minimumSize: const Size(double.infinity, 45),
              ),
              icon: const Icon(Icons.send, color: Colors.white),
              label: const Text('WhatsApp-ல் அனுப்பு',
                  style: TextStyle(color: Colors.white, fontSize: 16)),
              onPressed: () async {
                String text = _messageController.text;
                for (var contact in contacts) {
                  if (contact.phones.isNotEmpty) {
                    String phone = contact.phones.first.number
                        .replaceAll(RegExp(r'[^\d+]'), '');
                    String url =
                        "https://wa.me/$phone?text=${Uri.encodeComponent(text)}";
                    final Uri uri = Uri.parse(url);
                    if (await canLaunchUrl(uri)) {
                      await launchUrl(uri,
                          mode: LaunchMode.externalApplication);
                      await Future.delayed(const Duration(seconds: 2));
                    }
                  }
                }
              },
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('WhatsApp Bulk Sender'),
        actions: [
          IconButton(
            icon: const Icon(Icons.group_add),
            onPressed: _createNewGroup,
          )
        ],
      ),
      body: savedGroups.isEmpty
          ? const Center(
              child: Text(
                'இன்னும் குரூப் எதுவும் உருவாக்கப்படவில்லை!\nமேலே உள்ள + Icon தட்டி குரூப் உருவாக்கவும்.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey, fontSize: 16),
              ),
            )
          : ListView.builder(
              itemCount: savedGroups.length,
              itemBuilder: (context, index) {
                String groupName = savedGroups.keys.elementAt(index);
                List<Contact> contacts = savedGroups[groupName]!;
                return Card(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  child: ListTile(
                    leading: const CircleAvatar(
                      backgroundColor: Color(0xFF075E54),
                      child: Icon(Icons.group, color: Colors.white),
                    ),
                    title: Text(groupName,
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('${contacts.length} காண்டாக்ட்கள் உள்ளன'),
                    trailing: const Icon(Icons.send, color: Color(0xFF25D366)),
                    onTap: () => _sendToGroup(groupName, contacts),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF25D366),
        onPressed: _createNewGroup,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}
